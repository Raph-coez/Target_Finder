while 1:
    print("Je deglingue le cul d'arnaud ville")